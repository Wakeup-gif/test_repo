# US Sign Tampermonkey Package

This package captures the current working userscripts plus the historical source and tooling used to build them.

## Folder map

- `CURRENT/SquareCoil/` — canonical scripts to install for SquareCoil.
- `CURRENT/Other-Sites/` — Acrobat and ChatGPT visual scripts.
- `CURRENT/assets/` — cursor assets referenced by the Full UI Theme and prior cursor iterations.
- `ARCHIVE/` — old, experimental, versioned, and modular source. Do not install these over CURRENT unless intentionally restoring/testing.
- `RESTORE-POINTS/` — rollback notes preserved from the redesign process.
- `DEVELOPMENT/` — optimization, patch, and GitHub Actions tooling used while iterating.
- `DOCS/` — install links, ownership rules, AI handoff prompt, manifest, and change summary.

## Recommended SquareCoil stack

Install the CURRENT SquareCoil scripts as separate full userscripts. Do not replace them with loader wrappers or `@require` shells.

1. US Sign Full UI Theme
2. US Sign UI Runtime Fixes
3. US Sign Menu Cleanup and Reorder
4. US Sign Project and Scope Workspace
5. US Sign Scope File Tools
6. US Sign Description File Path Tools
7. US Sign Design Job Tools
8. US Sign Sticky Project Rail

The scripts intentionally have separate ownership boundaries. The theme owns global paint/typography. Runtime owns logo/CKEditor compatibility. Design owns Design DOM/layout. Scope owns Scope DOM/layout. Description owns Description path extraction. Menu owns project navigation order. Sticky owns rail positioning. Scope File Tools owns Scope path actions.

## Important performance rule

Avoid broad permanent MutationObservers, body-wide color crawlers, frequent polling, nested backdrop filters on scrolling cards, and repeated full-table scans. Prefer bounded discovery, scoped observers, signature checks, and CSS-only paint where possible.

## Current wallpaper note

The current Full UI Theme still contains a static Bing wallpaper URL. Daily Bing/Spotlight cycling was requested as the next enhancement but is not represented here as a completed production feature.

# Script ownership and conflict rules

## Full UI Theme
Owns global colors, typography, glass treatment, wallpaper, page-specific paint fixes, and cursor styling. Do not use it to move Design/Scope DOM structure.

## UI Runtime Fixes
Owns cached logo handling and CKEditor iframe compatibility. This is where iframe-only visual issues must be fixed because parent-page CSS cannot reach CKEditor iframe content.

## Design Job Tools
Owns Design workspace restructuring, overview/summary/actionbar, Design/Files/Description placement, Design data refresh, and bounded Design discovery.

## Project and Scope Workspace
Owns Scope page restructuring and Scope editor shell. Keep its grid/layout logic isolated from the global theme.

## Description File Path Tools
Owns Description path extraction and toolbar generation. Observe only actual Description content, not the whole page.

## Scope File Tools
Owns Scope path/open-file actions such as OneCommander integration.

## Menu Cleanup
Owns main/project navigation ordering and hidden menu entries. Avoid permanent observers.

## Sticky Project Rail
Owns sticky project rail behavior only.

## Rule for visual fixes
Before adding a new override, identify which script paints or creates the element. Fix the owner first. Example: the yellow Description highlight was inside CKEditor and therefore belonged to UI Runtime Fixes, not Full UI Theme.

# Current raw install links

## US Sign Full UI Theme v2.1.19
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Full-UI-Theme.user.js

## US Sign - Design Job Tools v4.1.2
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Design-Job-Tools.user.js

## US Sign - UI Runtime Fixes v3.1.2
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-UI-Runtime-Fixes.user.js

## US Sign - Description File Path Tools v2.3.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Description-File-Path-Tools.user.js

## US Sign Menu Cleanup and Reorder v3.0.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Menu-Cleanup.user.js

## US Sign Project and Scope Workspace v1.2.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Project-Scope-Workspace.user.js

## US Sign Scope of Work File Tools v2.6.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Scope-File-Tools.user.js

## US Sign Sticky Project Rail v2.1.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Sticky-Project-Rail-Installer.user.js

## Adobe Acrobat - US Sign Colors v1.2.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/Adobe-Acrobat-US-Sign-Colors.user.js

## ChatGPT - US Sign Glass Theme v1.0.0
https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/ChatGPT-US-Sign-Glass-Theme.user.js

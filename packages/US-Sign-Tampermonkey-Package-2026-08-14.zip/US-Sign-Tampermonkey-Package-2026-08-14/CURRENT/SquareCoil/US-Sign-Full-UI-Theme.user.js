// ==UserScript==
// @name         US Sign Full UI Theme
// @namespace    us-sign-full-modules
// @version      2.1.19
// @description  Stable SquareCoil layout with Roxborough display typography, blue glass chrome, frosted Project Search panels, corrected Task-page text contrast, blurred Job Dashboard glass, and a lightweight custom cursor.
// @match        https://ussignandmill.squarecoil.net/*
// @run-at       document-start
// @grant        GM_addStyle
// @noframes
// @updateURL    https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Full-UI-Theme.user.js
// @downloadURL  https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/US-Sign-Full-UI-Theme.user.js
// ==/UserScript==

(function () {
  "use strict";

  GM_addStyle(String.raw`
    @import url("https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;650;700&display=swap");

    :root {
      --us-bg: rgba(9, 15, 23, 0.52);
      --us-bg-elevated: rgba(16, 24, 34, 0.82);
      --us-bg-soft: rgba(22, 31, 42, 0.76);
      --us-glass: rgba(18, 27, 38, 0.70);
      --us-glass-strong: rgba(13, 21, 31, 0.86);
      --us-glass-soft: rgba(255, 255, 255, 0.045);
      --us-hover: rgba(100, 180, 255, 0.10);
      --us-text: #f5f8fb;
      --us-text-soft: #d2d9e1;
      --us-text-muted: #96a5b5;
      --us-accent: #8ecbff;
      --us-accent-soft: rgba(10, 132, 255, 0.18);
      --us-success: #78a88a;
      --us-warning: #c7a96b;
      --us-danger: #c47a7a;
      --us-info: #78c7ff;
      --us-border: rgba(169, 211, 247, 0.12);
      --us-border-strong: rgba(181, 220, 252, 0.19);
      --us-border-focus: rgba(10, 132, 255, 0.52);
      --us-shadow-sm: 0 4px 14px rgba(0, 0, 0, 0.18);
      --us-shadow-md: 0 12px 32px rgba(0, 0, 0, 0.24);
      --us-shadow-lg: 0 22px 54px rgba(0, 0, 0, 0.34);
      --us-radius-sm: 7px;
      --us-radius-md: 10px;
      --us-radius-lg: 14px;
      --us-font: "Manrope", "Avenir Next", "SF Pro Text", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      --us-mono: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
      --us-wallpaper: url("https://www.bing.com/th?id=OBTQ.BTA9ACD46ADE4DF290D5640B661E6A5C8CF666B651507F76309661E06C8AA70FB2&rs=2&c=1");
    }

    html,
    body {
      min-height: 100% !important;
      margin: 0 !important;
      padding-top: 0 !important;
      color: var(--us-text) !important;
      background: var(--us-bg) !important;
      background-color: var(--us-bg) !important;
      background-image: none !important;
      font-family: var(--us-font) !important;
      letter-spacing: 0 !important;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    ::selection {
      color: var(--us-text) !important;
      background: rgba(193, 204, 215, 0.28) !important;
    }

    /* Canvas and tray repair. This intentionally overrides native white tray backgrounds. */
    html body #main,
    html body #content_wrapper,
    html body #content,
    html body #content > .tray,
    html body #content > .tray-left,
    html body #content > .tray-right,
    html body #content > .tray-center,
    html body .tray,
    html body .tray-left,
    html body .tray-right,
    html body .tray-center,
    html body .tray-inner,
    html body [class^="tray-"],
    html body [class*=" tray-"],
    html body .content,
    html body .content-wrapper,
    html body .page-content,
    html body .content-body,
    html body .main-content,
    html body .main-panel,
    html body .admin-panels,
    html body .dashboard,
    html body .dashboard-page,
    html body .container,
    html body .container-fluid,
    html body .pl15,
    html body .pr15,
    html body .pl15.pr15 {
      color: var(--us-text) !important;
      background: var(--us-bg) !important;
      background-color: var(--us-bg) !important;
      background-image: none !important;
    }

    html body #content .row,
    html body .tray .row,
    html body .tray-center .row,
    html body #content [class*="col-"],
    html body .tray [class*="col-"],
    html body .tray-center [class*="col-"] {
      background-color: transparent !important;
      background-image: none !important;
    }

    #content {
      display: block !important;
      min-height: calc(100vh - 60px) !important;
    }

    .container,
    .container-fluid {
      margin-right: auto;
      margin-left: auto;
      padding-right: 11px;
      padding-left: 11px;
    }

    .row {
      margin-right: -11px !important;
      margin-left: -11px !important;
    }

    .row::before,
    .row::after {
      display: table;
      content: " ";
    }

    .row::after {
      clear: both;
    }

    [class*="col-xs-"],
    [class*="col-sm-"],
    [class*="col-md-"],
    [class*="col-lg-"],
    [class*="col-xl-"] {
      position: relative;
      min-height: 1px;
      padding-right: 11px !important;
      padding-left: 11px !important;
    }

    body,
    input,
    textarea,
    select,
    button {
      font-family: var(--us-font) !important;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    .panel-title,
    #pmlt h1,
    #pmlt h2 {
      color: var(--us-text) !important;
      font-family: var(--us-font) !important;
      font-weight: 650 !important;
      letter-spacing: -0.015em !important;
      text-transform: none !important;
      text-shadow: none !important;
    }

    p,
    li,
    label,
    td,
    th,
    address {
      color: var(--us-text-soft) !important;
    }

    small,
    .text-muted,
    .help-block,
    .panel-heading small,
    #pmlt small {
      color: var(--us-text-muted) !important;
    }

    strong,
    b {
      color: var(--us-text) !important;
      font-weight: 650 !important;
    }

    a,
    .design-link,
    .panel-body a,
    #pmlt a,
    #project_menu a {
      color: var(--us-accent) !important;
      text-decoration: none !important;
      text-shadow: none !important;
    }

    a:hover,
    a:focus,
    .design-link:hover,
    .panel-body a:hover,
    #pmlt a:hover,
    #project_menu a:hover {
      color: #fff !important;
    }

    header,
    header.navbar,
    .navbar,
    .navbar-fixed-top,
    #topbar,
    .topbar {
      top: 0 !important;
      margin-top: 0 !important;
      color: var(--us-text) !important;
      background: rgba(20, 24, 29, 0.96) !important;
      background-image: none !important;
      border: 0 !important;
      border-bottom: 1px solid var(--us-border) !important;
      box-shadow: var(--us-shadow-sm) !important;
      transform: none !important;
    }

    header::before,
    header::after,
    .navbar::before,
    .navbar::after,
    #topbar::before,
    #topbar::after {
      content: none !important;
      display: none !important;
    }

    header.navbar .navbar-brand,
    header.navbar .navbar-branding,
    html body #logo,
    html body .logo,
    html body .brand {
      overflow: visible !important;
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
    }

    header.navbar .navbar-brand img,
    header.navbar img[src*="US-Sign" i],
    header.navbar img[src*="USSIGN" i],
    header.navbar img[src*="logo" i] {
      position: relative !important;
      z-index: 20 !important;
      display: block !important;
      visibility: visible !important;
      width: auto !important;
      max-width: 180px !important;
      height: auto !important;
      max-height: 52px !important;
      object-fit: contain !important;
      object-position: left center !important;
      opacity: 1 !important;
      background: transparent !important;
      border: 0 !important;
      box-shadow: none !important;
      filter: none !important;
    }

    #sidebar_left {
      color: var(--us-text-soft) !important;
      background: rgba(18, 22, 27, 0.96) !important;
      background-image: none !important;
      border-right: 1px solid var(--us-border) !important;
      box-shadow: var(--us-shadow-sm) !important;
    }

    #sidebar_left a,
    #sidebar_left .nav > li > a {
      min-height: 34px !important;
      color: var(--us-text-soft) !important;
      background: transparent !important;
      border: 0 !important;
      border-radius: var(--us-radius-sm) !important;
      font-weight: 500 !important;
      text-transform: none !important;
    }

    #sidebar_left a:hover,
    #sidebar_left .nav > li > a:hover {
      color: var(--us-text) !important;
      background: var(--us-hover) !important;
    }

    #sidebar_left .nav > li.active > a,
    #sidebar_left .active > a,
    #sidebar_left a.active {
      color: var(--us-text) !important;
      background: var(--us-accent-soft) !important;
      border: 1px solid rgba(193, 204, 215, 0.12) !important;
    }

    #pmlt {
      min-height: calc(100vh - 60px) !important;
      color: var(--us-text-soft) !important;
      background: rgba(18, 22, 27, 0.96) !important;
      background-image: none !important;
      border-right: 1px solid var(--us-border) !important;
      box-shadow: none !important;
    }

    #pmlt::before,
    #pmlt::after {
      content: none !important;
      display: none !important;
    }

    #pmlt h1,
    #pmlt h1 * {
      color: var(--us-text) !important;
      text-shadow: none !important;
    }

    #pmlt h2,
    #pmlt h3,
    #pmlt small,
    #pmlt strong,
    #pmlt div,
    #pmlt li,
    #pmlt address {
      color: var(--us-text-soft) !important;
    }

    .panel,
    .panel-default,
    .well,
    .modal-content,
    .popover,
    .dropdown-menu,
    #customer-info,
    #customer-name,
    #showbtns,
    #mapcontainer,
    #filesbox,
    #descriptionbox,
    #projectbox,
    #designbox,
    .note-editor,
    .cke {
      position: relative !important;
      color: var(--us-text) !important;
      background: var(--us-glass) !important;
      background-image: none !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-lg) !important;
      box-shadow: var(--us-shadow-sm) !important;
      animation: none !important;
    }

    .panel::before,
    .panel::after,
    .well::before,
    .well::after,
    .modal-content::before,
    .modal-content::after,
    #customer-info::before,
    #customer-info::after,
    #filesbox::before,
    #filesbox::after,
    #descriptionbox::before,
    #descriptionbox::after,
    #designbox::before,
    #designbox::after {
      content: none !important;
      display: none !important;
    }

    .panel-heading,
    .panel-footer,
    .modal-header,
    .modal-footer,
    .cke_top,
    .cke_bottom,
    .note-toolbar {
      color: var(--us-text) !important;
      background: rgba(255, 255, 255, 0.025) !important;
      background-image: none !important;
      border-color: var(--us-border) !important;
      box-shadow: none !important;
    }

    .panel-body,
    .modal-body,
    .popover-content {
      color: var(--us-text) !important;
      background: transparent !important;
      border: 0 !important;
    }

    html body #content table,
    html body #content .table,
    html body .tray-center table,
    html body .tray-center .table,
    html body .panel table,
    html body .panel .table,
    html body .tab-content table,
    html body .tab-content .table {
      width: 100%;
      color: var(--us-text) !important;
      background: rgba(255, 255, 255, 0.018) !important;
      border: 1px solid var(--us-border) !important;
      border-collapse: separate !important;
      border-spacing: 0 !important;
      border-radius: var(--us-radius-md) !important;
      box-shadow: none !important;
    }

    html body #content table thead,
    html body #content table thead tr,
    html body #content table thead th,
    html body .tray-center table thead th {
      color: var(--us-text-soft) !important;
      background: rgba(255, 255, 255, 0.035) !important;
      border-color: var(--us-border) !important;
      font-weight: 600 !important;
      text-transform: none !important;
    }

    html body #content table tbody,
    html body #content table tbody tr,
    html body #content table tbody td,
    html body #content table tbody th,
    html body .tray-center table tbody tr,
    html body .tray-center table tbody td,
    html body .tray-center table tbody th {
      color: var(--us-text-soft) !important;
      background: transparent !important;
      border-color: var(--us-border) !important;
      box-shadow: none !important;
    }

    html body #content table tbody tr:hover,
    html body .tray-center table tbody tr:hover {
      color: var(--us-text) !important;
      background: var(--us-hover) !important;
    }

    .btn,
    button,
    input[type="button"],
    input[type="submit"] {
      position: relative !important;
      overflow: visible !important;
      min-height: 34px !important;
      padding: 7px 12px !important;
      color: var(--us-text) !important;
      background: rgba(255, 255, 255, 0.055) !important;
      background-image: none !important;
      border: 1px solid var(--us-border-strong) !important;
      border-radius: var(--us-radius-sm) !important;
      box-shadow: none !important;
      font-weight: 550 !important;
      text-transform: none !important;
      text-shadow: none !important;
      transform: none !important;
      animation: none !important;
    }

    .btn::before,
    .btn::after,
    button::before,
    button::after {
      content: none !important;
      display: none !important;
    }

    .btn:hover,
    .btn:focus,
    button:hover,
    button:focus,
    input[type="button"]:hover,
    input[type="submit"]:hover {
      color: #fff !important;
      background: rgba(255, 255, 255, 0.09) !important;
      border-color: rgba(255, 255, 255, 0.22) !important;
    }

    .btn-primary,
    .btn-info {
      color: #edf2f6 !important;
      background: rgba(155, 172, 189, 0.18) !important;
      border-color: rgba(193, 204, 215, 0.24) !important;
    }

    .btn-success {
      color: #dce9e0 !important;
      background: rgba(120, 168, 138, 0.17) !important;
      border-color: rgba(120, 168, 138, 0.28) !important;
    }

    .btn-warning,
    a[href*="clock"],
    .clock-actions,
    .btn[href*="clock"] {
      color: #eee5d2 !important;
      background: rgba(199, 169, 107, 0.16) !important;
      border-color: rgba(199, 169, 107, 0.27) !important;
    }

    .btn-danger {
      color: #f0dcdc !important;
      background: rgba(196, 122, 122, 0.16) !important;
      border-color: rgba(196, 122, 122, 0.28) !important;
    }

    input,
    textarea,
    select,
    .form-control {
      color: var(--us-text) !important;
      background: rgba(255, 255, 255, 0.035) !important;
      background-image: none !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-sm) !important;
      box-shadow: none !important;
    }

    input:focus,
    textarea:focus,
    select:focus,
    .form-control:focus {
      border-color: var(--us-border-focus) !important;
      box-shadow: 0 0 0 3px rgba(193, 204, 215, 0.08) !important;
      outline: none !important;
    }

    input::placeholder,
    textarea::placeholder {
      color: var(--us-text-muted) !important;
    }

    select,
    select.form-control,
    #pmlt select,
    #content select,
    .panel select,
    .panel-body select {
      padding-right: 10px !important;
      appearance: auto !important;
      -webkit-appearance: auto !important;
    }

    /* Existing Projects filters: own the complete select wrapper, not just the native select. */
    html body #content .tray-left form#form label.field.select,
    html body #content .tray-left form#form .field.select {
      color-scheme: dark !important;
      color: var(--us-text-soft) !important;
      background: var(--us-bg-soft) !important;
      background-color: var(--us-bg-soft) !important;
      background-image: none !important;
      border-radius: var(--us-radius-sm) !important;
      box-shadow: none !important;
    }

    html body #content .tray-left form#form label.field.select::before,
    html body #content .tray-left form#form label.field.select::after,
    html body #content .tray-left form#form .field.select::before,
    html body #content .tray-left form#form .field.select::after {
      background: transparent !important;
      background-image: none !important;
      box-shadow: none !important;
    }

    html body #content .tray-left form#form .field.select select,
    html body #content .tray-left form#form select.input-sm {
      color-scheme: dark !important;
      forced-color-adjust: none !important;
      color: var(--us-text-soft) !important;
      -webkit-text-fill-color: var(--us-text-soft) !important;
      background: #1c2127 !important;
      background-color: #1c2127 !important;
      background-image: none !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-sm) !important;
      box-shadow: none !important;
      opacity: 1 !important;
      filter: none !important;
      mix-blend-mode: normal !important;
      appearance: none !important;
      -webkit-appearance: none !important;
    }

    html body #content .tray-left form#form .field.select select:disabled,
    html body #content .tray-left form#form .field.select select[disabled],
    html body #content .tray-left form#form select.input-sm:disabled,
    html body #content .tray-left form#form select.input-sm[disabled] {
      color: var(--us-text-muted) !important;
      -webkit-text-fill-color: var(--us-text-muted) !important;
      background: #1c2127 !important;
      background-color: #1c2127 !important;
      border-color: var(--us-border) !important;
      opacity: 1 !important;
      cursor: default !important;
    }

    html body #content .tray-left form#form .field.select select:hover,
    html body #content .tray-left form#form .field.select select:focus,
    html body #content .tray-left form#form select.input-sm:hover,
    html body #content .tray-left form#form select.input-sm:focus {
      color: var(--us-text) !important;
      -webkit-text-fill-color: var(--us-text) !important;
      background: #242a31 !important;
      background-color: #242a31 !important;
      border-color: var(--us-border-focus) !important;
      outline: none !important;
    }

    html body #content .tray-left form#form .field.select > i.arrow.double {
      color: var(--us-text-muted) !important;
      border-top-color: var(--us-text-muted) !important;
      border-bottom-color: var(--us-text-muted) !important;
      opacity: 0.9 !important;
      pointer-events: none !important;
    }

    html body #content .tray-left form#form select option,
    html body #content .tray-left form#form select optgroup {
      color: var(--us-text-soft) !important;
      background: var(--us-bg-elevated) !important;
      background-color: var(--us-bg-elevated) !important;
    }

    select option,
    select optgroup {
      color: var(--us-text) !important;
      background: var(--us-bg-elevated) !important;
    }

    .alert,
    .alert-info,
    .alert-success,
    .alert-warning,
    .alert-danger,
    .alert-micro {
      background: rgba(255, 255, 255, 0.035) !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-md) !important;
      box-shadow: none !important;
    }

    .dropdown-menu,
    .popover,
    .tooltip-inner,
    .tt-dropdown-menu,
    .daterangepicker.dropdown-menu,
    .colorpicker.dropdown-menu,
    .datepicker,
    .ui-datepicker,
    .bootstrap-datetimepicker-widget,
    .multiselect-container.dropdown-menu,
    .select2-dropdown,
    .select2-container .select2-selection,
    .select2-container .select2-selection--single,
    .select2-container .select2-selection--multiple {
      z-index: 2147483000 !important;
      color: var(--us-text) !important;
      background: rgba(25, 29, 35, 0.99) !important;
      background-image: none !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-md) !important;
      box-shadow: var(--us-shadow-lg) !important;
    }

    .dropdown-menu > li > a,
    .tt-suggestion,
    .multiselect-container.dropdown-menu > li > a > label,
    .select2-results__option {
      color: var(--us-text-soft) !important;
      border-radius: var(--us-radius-sm) !important;
    }

    .dropdown-menu > li > a:hover,
    .dropdown-menu > li > a:focus,
    .tt-suggestion:hover,
    .tt-suggestion.tt-cursor,
    .select2-results__option--highlighted,
    .select2-results__option[aria-selected="true"] {
      color: var(--us-text) !important;
      background: var(--us-hover) !important;
    }

    .tab-block,
    .tab-block .tab-content,
    .page-tabs,
    .tabs-bg.nav-tabs,
    .tabs-bg.tabs-below {
      color: var(--us-text) !important;
      background: var(--us-glass) !important;
      background-image: none !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-lg) !important;
      box-shadow: var(--us-shadow-sm) !important;
    }

    .nav-tabs > li > a,
    .tabs-left > li > a,
    .tabs-right > li > a,
    .tabs-below > li > a,
    .panel-tabs > li > a {
      color: var(--us-text-muted) !important;
      background: transparent !important;
      border: 1px solid transparent !important;
      border-radius: var(--us-radius-sm) !important;
      text-transform: none !important;
    }

    .nav-tabs > li.active > a,
    .nav-tabs > li.active > a:hover,
    .nav-tabs > li.active > a:focus,
    .tabs-left > li.active > a {
      color: var(--us-text) !important;
      background: var(--us-accent-soft) !important;
      border-color: rgba(193, 204, 215, 0.14) !important;
    }

    .cke,
    .cke_chrome,
    .admin-skin.cke_chrome,
    .cke_inner,
    .note-editor,
    .markItUp,
    .md-editor {
      color: var(--us-text) !important;
      background: var(--us-glass-strong) !important;
      background-image: none !important;
      border-color: var(--us-border) !important;
      box-shadow: var(--us-shadow-sm) !important;
    }

    .cke_toolgroup,
    .cke_combo_button,
    .note-btn-group,
    .note-editor .btn-group,
    .md-editor > .md-header .btn-group {
      background: rgba(255, 255, 255, 0.03) !important;
      border-color: var(--us-border) !important;
      box-shadow: none !important;
    }

    .cke_contents,
    .cke_wysiwyg_frame,
    .cke_wysiwyg_div,
    .note-editor .note-editable,
    .markItUpEditor,
    .md-editor > textarea,
    .md-editor > .md-preview {
      color: var(--us-text) !important;
      background: rgba(17, 20, 24, 0.92) !important;
      border-color: var(--us-border) !important;
      text-shadow: none !important;
    }

    .pagination,
    .dataTables_paginate {
      background: transparent !important;
      border: 0 !important;
    }

    .pagination > li > a,
    .pagination > li > span,
    .dataTables_paginate .paginate_button {
      color: var(--us-text-soft) !important;
      background: rgba(255, 255, 255, 0.035) !important;
      border: 1px solid var(--us-border) !important;
      border-radius: var(--us-radius-sm) !important;
      box-shadow: none !important;
    }

    .pagination > .active > a,
    .pagination > .active > span,
    .dataTables_paginate .paginate_button.current {
      color: var(--us-text) !important;
      background: var(--us-accent-soft) !important;
      border-color: rgba(193, 204, 215, 0.18) !important;
    }

    .duplicate-modal,
    .modal-backdrop,
    #modal-overlay.duplicate-modal-2,
    .duplicate-modal-2,
    #time-remaining-popup-container {
      background: rgba(5, 7, 9, 0.68) !important;
    }

    .duplicate-modal-content,
    .modal-content,
    .bootbox .modal-content,
    .ui-dialog,
    .ui-widget-content,
    .duplicate-modal-content-2,
    #time-remaining-popup-modal,
    #remaining-time-in-popup,
    #show-materials-used-warning-modal {
      color: var(--us-text) !important;
      background: var(--us-glass-strong) !important;
      background-image: none !important;
      border: 1px solid var(--us-border-strong) !important;
      border-radius: var(--us-radius-lg) !important;
      box-shadow: var(--us-shadow-lg) !important;
    }

    mark,
    .marker,
    [style*="background-color: yellow" i],
    [style*="background: yellow" i],
    [style*="#ffff00" i],
    [style*="#ff0" i] {
      display: inline !important;
      color: var(--us-text) !important;
      -webkit-text-fill-color: var(--us-text) !important;
      background: rgba(211, 186, 134, 0.18) !important;
      border-radius: 4px !important;
      text-shadow: none !important;
      box-shadow: inset 0 0 0 1px rgba(211, 186, 134, 0.16) !important;
    }

    html body :is(#descriptionbox, #designbox, .us-sign-description-panel, .us-sign-readable-content)
    :is([style*="color:blue" i], [style*="color: blue" i], [style*="#0000ff" i], [style*="#00f" i], [style*="rgb(0, 0, 255)" i], font[color="blue" i], font[color="#0000ff" i]) {
      color: #a9c2d8 !important;
      -webkit-text-fill-color: #a9c2d8 !important;
      text-shadow: none !important;
      filter: none !important;
    }

    html body :is(#descriptionbox, #designbox, .us-sign-description-panel, .us-sign-readable-content)
    :is([style*="color:red" i], [style*="color: red" i], [style*="#ff0000" i], [style*="#f00" i], font[color="red" i], font[color="#ff0000" i]) {
      color: #c49a96 !important;
      -webkit-text-fill-color: #c49a96 !important;
    }

    html body :is(#descriptionbox, #designbox, .us-sign-description-panel, .us-sign-readable-content)
    :is([style*="color:green" i], [style*="color: green" i], [style*="#008000" i], [style*="#00ff00" i], font[color="green" i], font[color="#008000" i]) {
      color: #acd0b5 !important;
      -webkit-text-fill-color: #acd0b5 !important;
    }

    /* Description rich-text cleanup: remove inherited highlight chips while preserving text formatting. */
    html body :is(#descriptionbox, .us-sign-description-panel)
    .panel-body :is(
      mark,
      .marker,
      [style*="background:" i],
      [style*="background-color:" i],
      [bgcolor]
    ) {
      background: transparent !important;
      background-color: transparent !important;
      background-image: none !important;
      box-shadow: none !important;
      border-radius: 0 !important;
      text-shadow: none !important;
    }

    ::-webkit-scrollbar {
      width: 10px;
      height: 10px;
    }

    ::-webkit-scrollbar-track {
      background: var(--us-bg) !important;
    }

    ::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.16) !important;
      border: 2px solid var(--us-bg) !important;
      border-radius: 999px !important;
    }

    @media (min-width: 992px) {
      .col-md-1 { width: 8.33333333% !important; }
      .col-md-2 { width: 16.66666667% !important; }
      .col-md-3 { width: 25% !important; }
      .col-md-4 { width: 33.33333333% !important; }
      .col-md-5 { width: 41.66666667% !important; }
      .col-md-6 { width: 50% !important; }
      .col-md-7 { width: 58.33333333% !important; }
      .col-md-8 { width: 66.66666667% !important; }
      .col-md-9 { width: 75% !important; }
      .col-md-10 { width: 83.33333333% !important; }
      .col-md-11 { width: 91.66666667% !important; }
      .col-md-12 { width: 100% !important; }
    }

    @media (max-width: 760px) {
      header.navbar .navbar-brand img {
        max-width: 150px !important;
      }

      .navbar-form,
      .timeclock-container {
        max-width: 100% !important;
      }
    }



    /* =========================================================
       v2.1.1 VISUAL-ONLY WALLPAPER + BLUE GLASS
       Source layout is the known-good v1.1.2 immediately before the
       wallpaper commit. Paint changes only: no display/position/spacing,
       tray geometry, widths, transforms, or runtime DOM mutation.
    ========================================================= */

    html {
      background-color: #081019 !important;
      background-image:
        radial-gradient(circle at 78% 0%, rgba(42, 135, 255, 0.18), transparent 38%),
        radial-gradient(circle at 14% 100%, rgba(100, 210, 255, 0.08), transparent 34%),
        linear-gradient(rgba(4, 8, 13, 0.30), rgba(6, 11, 17, 0.56)),
        var(--us-wallpaper) !important;
      background-position: center center !important;
      background-size: cover !important;
      background-repeat: no-repeat !important;
      background-attachment: fixed !important;
    }

    body {
      background: rgba(7, 11, 16, 0.10) !important;
      background-color: rgba(7, 11, 16, 0.10) !important;
      background-image: none !important;
    }

    header,
    header.navbar,
    .navbar,
    .navbar-fixed-top,
    #topbar,
    .topbar {
      background: rgba(11, 18, 28, 0.84) !important;
      background-color: rgba(11, 18, 28, 0.58) !important;
      border-bottom-color: rgba(100, 210, 255, 0.13) !important;
    }

    #sidebar_left,
    #pmlt {
      background: rgba(10, 17, 26, 0.84) !important;
      background-color: rgba(10, 17, 26, 0.84) !important;
      border-color: rgba(100, 210, 255, 0.13) !important;
    }

    .panel,
    .panel-default,
    .well,
    .modal-content,
    .popover,
    .dropdown-menu,
    #customer-info,
    #customer-name,
    #showbtns,
    #mapcontainer,
    #filesbox,
    #descriptionbox,
    #projectbox,
    #designbox,
    .note-editor,
    .cke {
      background: var(--us-glass) !important;
      background-color: var(--us-glass) !important;
      border-color: var(--us-border) !important;
    }


    html body #main,
    html body #content_wrapper {
      background-color: #081019 !important;
      background-image:
        linear-gradient(rgba(4, 8, 13, 0.28), rgba(6, 11, 17, 0.54)),
        var(--us-wallpaper) !important;
      background-position: center center !important;
      background-size: cover !important;
      background-repeat: no-repeat !important;
      background-attachment: fixed !important;
    }

    /* =========================================================
       v2.1.4 CANVAS WALLPAPER STACK
       Keep the v1.1.2 geometry untouched. These structural wrappers retain
       their normal dimensions and flow; only their paint is made lighter so
       the root wallpaper remains visible through stacked canvas layers.
    ========================================================= */

    html body #content,
    html body #content > .tray,
    html body #content > .tray-left,
    html body #content > .tray-right,
    html body #content > .tray-center,
    html body .tray,
    html body .tray-left,
    html body .tray-right,
    html body .tray-center,
    html body .tray-inner,
    html body [class^="tray-"],
    html body [class*=" tray-"],
    html body .content,
    html body .content-wrapper,
    html body .page-content,
    html body .content-body,
    html body .main-content,
    html body .main-panel,
    html body .admin-panels,
    html body .dashboard,
    html body .dashboard-page,
    html body .container,
    html body .container-fluid,
    html body .pl15,
    html body .pr15,
    html body .pl15.pr15 {
      background: rgba(8, 14, 22, 0.10) !important;
      background-color: rgba(8, 14, 22, 0.10) !important;
      background-image: none !important;
    }

    @supports ((-webkit-backdrop-filter: blur(1px)) or (backdrop-filter: blur(1px))) {
      header.navbar,
      #sidebar_left,
      #pmlt,
      .panel,
      .panel-default,
      .well,
      .modal-content,
      .popover,
      .dropdown-menu,
      #customer-info,
      #customer-name,
      #filesbox,
      #descriptionbox,
      #projectbox,
      #designbox {
        -webkit-backdrop-filter: blur(16px) saturate(130%) !important;
        backdrop-filter: blur(16px) saturate(130%) !important;
      }
    }

    #sidebar_left .nav > li.active > a,
    #sidebar_left .active > a,
    #sidebar_left a.active,
    .pagination > .active > a,
    .pagination > .active > span {
      background: rgba(10, 132, 255, 0.20) !important;
      border-color: rgba(100, 210, 255, 0.20) !important;
    }



    /* =========================================================
       v2.1.5 GLASS POLISH
       Visual hierarchy only. No display, position, sizing, spacing,
       transforms, tray geometry, or runtime DOM mutation.
    ========================================================= */

    :root {
      --us-glass-rail: rgba(9, 17, 27, 0.50);
      --us-glass-header: rgba(10, 18, 28, 0.58);
      --us-glass-hero: rgba(19, 31, 45, 0.32);
      --us-glass-card: rgba(13, 23, 35, 0.40);
      --us-glass-card-strong: rgba(10, 19, 30, 0.48);
      --us-glass-inner: rgba(5, 12, 20, 0.24);
      --us-glass-edge: rgba(174, 219, 255, 0.15);
      --us-glass-edge-soft: rgba(174, 219, 255, 0.09);
      --us-glass-highlight: rgba(255, 255, 255, 0.055);
      --us-glow-blue: rgba(44, 145, 255, 0.12);
      --us-shadow-glass: 0 10px 30px rgba(0, 0, 0, 0.20), inset 0 1px 0 rgba(255, 255, 255, 0.045);
      --us-shadow-glass-strong: 0 14px 36px rgba(0, 0, 0, 0.26), inset 0 1px 0 rgba(255, 255, 255, 0.055);
    }

    header.navbar,
    #topbar,
    .topbar {
      background:
        linear-gradient(180deg, rgba(29, 48, 68, 0.54), rgba(6, 14, 23, 0.50)) !important;
      background-color: var(--us-glass-header) !important;
      border-bottom-color: var(--us-glass-edge-soft) !important;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.20), inset 0 -1px 0 rgba(92, 180, 255, 0.035) !important;
    }

    #sidebar_left {
      background:
        linear-gradient(180deg, rgba(18, 34, 49, 0.66), rgba(6, 14, 23, 0.58)) !important;
      background-color: rgba(9, 17, 27, 0.62) !important;
      border-right-color: var(--us-glass-edge-soft) !important;
      box-shadow: 10px 0 28px rgba(0, 0, 0, 0.12), inset -1px 0 0 rgba(255, 255, 255, 0.025) !important;
    }

    #pmlt {
      background:
        linear-gradient(180deg, rgba(20, 39, 56, 0.48), rgba(5, 13, 22, 0.46)) !important;
      background-color: var(--us-glass-rail) !important;
      border-right-color: var(--us-glass-edge) !important;
      box-shadow: 12px 0 30px rgba(0, 0, 0, 0.15), inset -1px 0 0 rgba(255, 255, 255, 0.035) !important;
    }

    #customer-name {
      background:
        linear-gradient(180deg, rgba(112, 150, 186, 0.22), rgba(20, 36, 54, 0.28)) !important;
      background-color: var(--us-glass-hero) !important;
      border-color: rgba(185, 222, 255, 0.16) !important;
      box-shadow: var(--us-shadow-glass), inset 0 1px 0 rgba(255, 255, 255, 0.065) !important;
    }

    #customer-info,
    #projectbox,
    #showbtns {
      background:
        linear-gradient(180deg, rgba(19, 36, 53, 0.50), rgba(6, 15, 25, 0.46)) !important;
      background-color: var(--us-glass-card-strong) !important;
      border-color: var(--us-glass-edge-soft) !important;
      box-shadow: var(--us-shadow-glass-strong) !important;
    }

    #descriptionbox,
    #designbox,
    #filesbox,
    .panel,
    .panel-default,
    .well {
      background:
        linear-gradient(180deg, rgba(25, 46, 65, 0.42), rgba(5, 14, 24, 0.38)) !important;
      background-color: var(--us-glass-card) !important;
      border-color: var(--us-glass-edge-soft) !important;
      box-shadow: var(--us-shadow-glass) !important;
    }

    #descriptionbox > .panel-heading,
    #designbox > .panel-heading,
    #filesbox > .panel-heading,
    .panel > .panel-heading {
      background:
        linear-gradient(180deg, rgba(106, 169, 222, 0.075), rgba(255, 255, 255, 0.012)) !important;
      background-color: rgba(255, 255, 255, 0.018) !important;
      border-bottom-color: var(--us-glass-edge-soft) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.035) !important;
    }

    #descriptionbox .panel-body,
    #designbox .panel-body,
    #filesbox .panel-body,
    #projectbox .panel-body,
    #customer-info .panel-body {
      background: rgba(3, 9, 16, 0.035) !important;
      background-color: rgba(3, 9, 16, 0.035) !important;
    }

    html body #content table,
    html body #content .table,
    html body .panel table,
    html body .panel .table {
      background: rgba(4, 11, 19, 0.20) !important;
      border-color: rgba(174, 219, 255, 0.085) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.018) !important;
    }

    html body #content table thead,
    html body #content table thead tr,
    html body #content table thead th,
    html body .panel table thead th {
      background: rgba(116, 173, 224, 0.035) !important;
      border-color: rgba(174, 219, 255, 0.075) !important;
    }

    html body #content table tbody tr:hover,
    html body .panel table tbody tr:hover {
      background: rgba(76, 158, 230, 0.065) !important;
    }

    input:not([type="button"]):not([type="submit"]):not([type="reset"]),
    textarea,
    select,
    .form-control {
      background: rgba(3, 10, 18, 0.36) !important;
      background-color: rgba(3, 10, 18, 0.36) !important;
      border-color: rgba(174, 219, 255, 0.11) !important;
      box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.16), inset 0 1px 0 rgba(255, 255, 255, 0.018) !important;
    }

    input:not([type="button"]):not([type="submit"]):not([type="reset"]):focus,
    textarea:focus,
    select:focus,
    .form-control:focus {
      border-color: rgba(86, 177, 255, 0.40) !important;
      box-shadow: 0 0 0 2px rgba(10, 132, 255, 0.10), inset 0 1px 2px rgba(0, 0, 0, 0.14) !important;
    }

    #sidebar_left .nav > li.active > a,
    #sidebar_left .active > a,
    #sidebar_left a.active {
      background:
        linear-gradient(180deg, rgba(35, 145, 255, 0.24), rgba(10, 90, 170, 0.16)) !important;
      border-color: rgba(115, 197, 255, 0.18) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.035) !important;
    }

    #pmlt a:hover,
    #project_menu a:hover {
      color: #ffffff !important;
      text-shadow: 0 0 14px rgba(104, 194, 255, 0.22) !important;
    }

    /* Blur only the large glass surfaces. Avoid nested backdrop filters. */
    @supports ((-webkit-backdrop-filter: blur(1px)) or (backdrop-filter: blur(1px))) {
      header.navbar,
      #sidebar_left,
      #pmlt,
      #customer-name,
      #customer-info,
      #projectbox,
      #descriptionbox,
      #designbox,
      #filesbox {
        -webkit-backdrop-filter: blur(18px) saturate(125%) !important;
        backdrop-filter: blur(18px) saturate(125%) !important;
      }

      #descriptionbox .panel,
      #designbox .panel,
      #filesbox .panel,
      #projectbox .panel,
      #customer-info .panel,
      #descriptionbox .well,
      #designbox .well,
      #filesbox .well {
        -webkit-backdrop-filter: none !important;
        backdrop-filter: none !important;
      }
    }



    /* =========================================================
       v2.1.7 TRUE GLASS SYSTEM
       ChatGPT-like restraint + macOS frosted translucency.
       Paint and typography only. No display, sizing, spacing,
       positioning, transforms, tray geometry, or DOM mutation.
    ========================================================= */

    :root {
      --us-glass-clear: rgba(8, 15, 24, 0.16);
      --us-glass-soft-clear: rgba(10, 18, 29, 0.21);
      --us-glass-medium-clear: rgba(9, 17, 28, 0.28);
      --us-glass-readable: rgba(8, 16, 27, 0.34);
      --us-glass-nav: rgba(8, 16, 27, 0.52);
      --us-hairline: rgba(220, 239, 255, 0.105);
      --us-hairline-bright: rgba(230, 244, 255, 0.16);
      --us-surface-shine: rgba(255, 255, 255, 0.045);
      --us-blue-haze: rgba(72, 151, 231, 0.065);
      --us-blue-haze-strong: rgba(74, 158, 245, 0.105);
      --us-text: rgba(247, 250, 253, 0.96);
      --us-text-soft: rgba(220, 228, 237, 0.84);
      --us-text-muted: rgba(166, 181, 198, 0.68);
      --us-accent: #83c4ff;
    }

    html,
    body,
    input,
    textarea,
    select,
    button,
    table,
    th,
    td,
    .panel,
    .panel-heading,
    .panel-body,
    #pmlt {
      font-family: var(--us-font) !important;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    .panel-title,
    #customer-name,
    #customer-name * {
      font-family: var(--us-font) !important;
      letter-spacing: -0.022em !important;
    }

    /* Navigation glass remains a little denser for legibility. */
    header.navbar,
    #topbar,
    .topbar {
      background:
        linear-gradient(180deg, rgba(29, 45, 62, 0.32), rgba(4, 11, 19, 0.24)),
        rgba(7, 14, 23, 0.38) !important;
      background-color: rgba(7, 14, 23, 0.38) !important;
      border-bottom-color: var(--us-hairline) !important;
      box-shadow:
        0 10px 28px rgba(0, 0, 0, 0.12),
        inset 0 -1px 0 rgba(255, 255, 255, 0.025) !important;
      -webkit-backdrop-filter: blur(24px) saturate(155%) !important;
      backdrop-filter: blur(24px) saturate(155%) !important;
    }

    #sidebar_left {
      background:
        linear-gradient(180deg, rgba(17, 31, 45, 0.44), rgba(5, 12, 21, 0.38)),
        rgba(7, 14, 23, 0.42) !important;
      background-color: rgba(7, 14, 23, 0.42) !important;
      border-right-color: var(--us-hairline) !important;
      box-shadow:
        10px 0 30px rgba(0, 0, 0, 0.09),
        inset -1px 0 0 rgba(255, 255, 255, 0.025) !important;
      -webkit-backdrop-filter: blur(24px) saturate(150%) !important;
      backdrop-filter: blur(24px) saturate(150%) !important;
    }

    #pmlt {
      background:
        linear-gradient(145deg, rgba(92, 166, 230, 0.055), transparent 44%),
        linear-gradient(180deg, rgba(11, 23, 36, 0.28), rgba(5, 12, 21, 0.22)) !important;
      background-color: rgba(7, 15, 25, 0.24) !important;
      border-right-color: var(--us-hairline) !important;
      box-shadow:
        10px 0 30px rgba(0, 0, 0, 0.08),
        inset -1px 0 0 rgba(255, 255, 255, 0.035) !important;
      -webkit-backdrop-filter: blur(22px) saturate(145%) !important;
      backdrop-filter: blur(22px) saturate(145%) !important;
    }

    /* Hero/title surface: luminous glass, not a solid banner. */
    #customer-name {
      background:
        linear-gradient(115deg, rgba(255, 255, 255, 0.075), transparent 32%),
        linear-gradient(180deg, rgba(114, 177, 230, 0.095), rgba(9, 17, 28, 0.12)) !important;
      background-color: rgba(10, 18, 29, 0.15) !important;
      border-color: var(--us-hairline-bright) !important;
      box-shadow:
        0 12px 34px rgba(0, 0, 0, 0.10),
        inset 0 1px 0 rgba(255, 255, 255, 0.075) !important;
      -webkit-backdrop-filter: blur(24px) saturate(150%) !important;
      backdrop-filter: blur(24px) saturate(150%) !important;
    }

    /* Job overview stays slightly denser because the data is tiny. */
    #customer-info,
    #projectbox,
    #showbtns {
      background:
        linear-gradient(145deg, rgba(88, 165, 232, 0.045), transparent 38%),
        linear-gradient(180deg, rgba(7, 16, 27, 0.31), rgba(5, 12, 21, 0.25)) !important;
      background-color: var(--us-glass-readable) !important;
      border-color: var(--us-hairline) !important;
      box-shadow:
        0 12px 30px rgba(0, 0, 0, 0.105),
        inset 0 1px 0 rgba(255, 255, 255, 0.035) !important;
      -webkit-backdrop-filter: blur(20px) saturate(145%) !important;
      backdrop-filter: blur(20px) saturate(145%) !important;
    }

    /* Main work panels: mostly transparent, like floating ChatGPT panes. */
    #descriptionbox,
    #designbox,
    #filesbox,
    .panel,
    .panel-default,
    .well {
      background:
        linear-gradient(145deg, rgba(119, 187, 241, 0.045), transparent 34%),
        linear-gradient(180deg, rgba(9, 18, 30, 0.20), rgba(5, 12, 21, 0.16)) !important;
      background-color: var(--us-glass-soft-clear) !important;
      border-color: var(--us-hairline) !important;
      box-shadow:
        0 10px 28px rgba(0, 0, 0, 0.085),
        inset 0 1px 0 rgba(255, 255, 255, 0.04) !important;
    }

    #descriptionbox,
    #designbox,
    #filesbox {
      -webkit-backdrop-filter: blur(20px) saturate(145%) !important;
      backdrop-filter: blur(20px) saturate(145%) !important;
    }

    #descriptionbox > .panel-heading,
    #designbox > .panel-heading,
    #filesbox > .panel-heading,
    .panel > .panel-heading,
    .panel-heading,
    .panel-footer {
      background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.04), rgba(86, 165, 231, 0.025)) !important;
      background-color: rgba(255, 255, 255, 0.018) !important;
      border-color: var(--us-hairline) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.035) !important;
    }

    #descriptionbox .panel-body,
    #designbox .panel-body,
    #filesbox .panel-body,
    #projectbox .panel-body,
    #customer-info .panel-body,
    .panel-body {
      background: rgba(5, 12, 20, 0.025) !important;
      background-color: rgba(5, 12, 20, 0.025) !important;
    }

    /* Tables should read as content, not nested black boxes. */
    html body #content table,
    html body #content .table,
    html body .panel table,
    html body .panel .table {
      background: rgba(5, 12, 20, 0.10) !important;
      background-color: rgba(5, 12, 20, 0.10) !important;
      border-color: rgba(220, 239, 255, 0.065) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.014) !important;
    }

    html body #content table thead,
    html body #content table thead tr,
    html body #content table thead th,
    html body .panel table thead th {
      background: rgba(117, 185, 239, 0.022) !important;
      border-color: rgba(220, 239, 255, 0.06) !important;
    }

    html body #content table tbody tr:hover,
    html body .panel table tbody tr:hover {
      background: rgba(92, 176, 246, 0.055) !important;
    }

    /* Inputs use a translucent smoked inset, not opaque charcoal. */
    input:not([type="button"]):not([type="submit"]):not([type="reset"]),
    textarea,
    select,
    .form-control {
      background: rgba(4, 11, 19, 0.24) !important;
      background-color: rgba(4, 11, 19, 0.24) !important;
      border-color: rgba(220, 239, 255, 0.085) !important;
      box-shadow:
        inset 0 1px 2px rgba(0, 0, 0, 0.11),
        inset 0 1px 0 rgba(255, 255, 255, 0.022) !important;
    }

    input:not([type="button"]):not([type="submit"]):not([type="reset"]):focus,
    textarea:focus,
    select:focus,
    .form-control:focus {
      border-color: rgba(103, 190, 255, 0.34) !important;
      box-shadow:
        0 0 0 2px rgba(10, 132, 255, 0.075),
        inset 0 1px 2px rgba(0, 0, 0, 0.10) !important;
    }

    /* Existing button geometry is untouched; paint becomes frosted. */
    .btn,
    button,
    input[type="button"],
    input[type="submit"] {
      background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.045), rgba(60, 125, 183, 0.025)),
        rgba(7, 15, 25, 0.24) !important;
      background-color: rgba(7, 15, 25, 0.24) !important;
      border-color: rgba(220, 239, 255, 0.10) !important;
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.035),
        0 4px 12px rgba(0, 0, 0, 0.07) !important;
    }

    .btn:hover,
    button:hover,
    input[type="button"]:hover,
    input[type="submit"]:hover {
      background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.07), rgba(72, 152, 220, 0.04)),
        rgba(9, 20, 33, 0.31) !important;
      border-color: rgba(131, 196, 255, 0.18) !important;
    }

    #sidebar_left .nav > li.active > a,
    #sidebar_left .active > a,
    #sidebar_left a.active {
      background:
        linear-gradient(180deg, rgba(53, 153, 245, 0.16), rgba(14, 92, 172, 0.075)) !important;
      border-color: rgba(126, 200, 255, 0.14) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.03) !important;
    }

    #pmlt a,
    #project_menu a {
      color: rgba(218, 230, 242, 0.88) !important;
    }

    #pmlt a:hover,
    #project_menu a:hover {
      color: #ffffff !important;
      text-shadow: 0 0 16px rgba(105, 193, 255, 0.18) !important;
    }


    /* =========================================================
       v2.1.8 PERFORMANCE TRUE GLASS
       Keep the wallpaper and layout. Remove expensive blur from scrolling
       content and override Design Job Tools' opaque runtime surfaces.
    ========================================================= */

    :root {
      --us-perf-glass: rgba(7, 15, 25, 0.13);
      --us-perf-glass-soft: rgba(9, 18, 30, 0.10);
      --us-perf-glass-readable: rgba(7, 15, 25, 0.20);
      --us-perf-hairline: rgba(226, 242, 255, 0.09);
      --us-perf-highlight: rgba(255, 255, 255, 0.035);
    }

    /* Scrolling content gets transparent paint only. Backdrop-filter on
       large moving surfaces is the main source of scroll/compositing jank. */
    html body #customer-name,
    html body #customer-info,
    html body #projectbox,
    html body #showbtns,
    html body #descriptionbox,
    html body #designbox,
    html body #filesbox,
    html body #content .panel,
    html body #content .panel-default,
    html body #content .well,
    html body #content .modal-content,
    html body #content .popover,
    html body #content .dropdown-menu {
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
    }

    html body #descriptionbox,
    html body #designbox,
    html body #filesbox,
    html body #content .panel,
    html body #content .panel-default,
    html body #content .well {
      background:
        linear-gradient(145deg, rgba(128, 194, 246, 0.028), transparent 32%),
        linear-gradient(180deg, rgba(8, 17, 28, 0.13), rgba(4, 10, 18, 0.09)) !important;
      background-color: var(--us-perf-glass) !important;
      border-color: var(--us-perf-hairline) !important;
      box-shadow:
        0 8px 24px rgba(0, 0, 0, 0.055),
        inset 0 1px 0 var(--us-perf-highlight) !important;
    }

    html body #customer-name {
      background:
        linear-gradient(110deg, rgba(255, 255, 255, 0.055), transparent 30%),
        linear-gradient(180deg, rgba(103, 174, 232, 0.07), rgba(7, 15, 25, 0.08)) !important;
      background-color: rgba(8, 16, 27, 0.10) !important;
      border-color: rgba(226, 242, 255, 0.12) !important;
      box-shadow:
        0 8px 26px rgba(0, 0, 0, 0.055),
        inset 0 1px 0 rgba(255, 255, 255, 0.055) !important;
    }

    html body #customer-info,
    html body #projectbox,
    html body #showbtns {
      background:
        linear-gradient(145deg, rgba(104, 176, 236, 0.026), transparent 36%),
        linear-gradient(180deg, rgba(6, 14, 24, 0.20), rgba(4, 10, 18, 0.15)) !important;
      background-color: var(--us-perf-glass-readable) !important;
      border-color: var(--us-perf-hairline) !important;
      box-shadow:
        0 8px 24px rgba(0, 0, 0, 0.065),
        inset 0 1px 0 rgba(255, 255, 255, 0.028) !important;
    }

    html body #content .panel-heading,
    html body #descriptionbox > .panel-heading,
    html body #designbox > .panel-heading,
    html body #filesbox > .panel-heading {
      background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.028), rgba(91, 168, 230, 0.014)) !important;
      background-color: rgba(255, 255, 255, 0.010) !important;
      border-color: var(--us-perf-hairline) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.025) !important;
    }

    html body #content .panel-body,
    html body #descriptionbox .panel-body,
    html body #designbox .panel-body,
    html body #filesbox .panel-body,
    html body #projectbox .panel-body,
    html body #customer-info .panel-body {
      background: transparent !important;
      background-color: transparent !important;
      background-image: none !important;
    }

    html body #content table,
    html body #content .table,
    html body #content .panel table,
    html body #content .panel .table {
      background: rgba(5, 12, 20, 0.055) !important;
      background-color: rgba(5, 12, 20, 0.055) !important;
      border-color: rgba(226, 242, 255, 0.05) !important;
      box-shadow: none !important;
    }

    /* Design Job Tools injects its CSS after the theme and defines .90/.96
       surfaces. Higher specificity + !important keeps those runtime cards
       aligned with the global glass system without editing layout behavior. */
    html body #us-sign-design-actionbar,
    html body #us-sign-job-overview,
    html body #us-sign-design-summary,
    html body #us-sign-design-bottom-grid,
    html body #us-sign-design-right-stack {
      --djt-surface: rgba(7, 15, 25, 0.14) !important;
      --djt-surface-strong: rgba(7, 15, 25, 0.17) !important;
      --djt-surface-soft: rgba(255, 255, 255, 0.018) !important;
      --djt-hover: rgba(118, 190, 246, 0.055) !important;
      --djt-border: rgba(226, 242, 255, 0.07) !important;
      --djt-border-strong: rgba(226, 242, 255, 0.105) !important;
      --djt-accent-soft: rgba(80, 165, 238, 0.10) !important;
      --djt-font: var(--us-font) !important;
    }

    html body #us-sign-design-actionbar {
      background:
        linear-gradient(180deg, rgba(255, 255, 255, 0.025), rgba(77, 151, 213, 0.012)),
        rgba(7, 15, 25, 0.16) !important;
      background-color: rgba(7, 15, 25, 0.16) !important;
      border-color: rgba(226, 242, 255, 0.075) !important;
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.026) !important;
    }

    html body #us-sign-job-overview,
    html body #us-sign-design-summary {
      background:
        linear-gradient(180deg, rgba(111, 181, 237, 0.018), rgba(5, 12, 20, 0.105)) !important;
      background-color: rgba(7, 15, 25, 0.13) !important;
      border-color: rgba(226, 242, 255, 0.065) !important;
      box-shadow: none !important;
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
    }

    html body #us-sign-job-overview .us-sign-overview-title,
    html body #us-sign-job-overview .us-sign-overview-field,
    html body #us-sign-design-summary > .us-sign-djt-summary-cell {
      background: transparent !important;
      background-color: transparent !important;
      border-color: rgba(226, 242, 255, 0.05) !important;
    }

    html body #us-sign-design-bottom-grid,
    html body #us-sign-design-right-stack,
    html body .us-sign-design-workbench,
    html body .us-sign-design-workspace-column {
      background: transparent !important;
      background-color: transparent !important;
      background-image: none !important;
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
      box-shadow: none !important;
    }

    html body #us-sign-design-bottom-grid > .us-sign-description-panel,
    html body #us-sign-design-right-stack > .us-sign-designs-panel,
    html body #us-sign-design-right-stack > .us-sign-files-panel {
      background:
        linear-gradient(145deg, rgba(119, 187, 241, 0.024), transparent 32%),
        rgba(6, 14, 24, 0.105) !important;
      background-color: rgba(6, 14, 24, 0.105) !important;
      border-color: rgba(226, 242, 255, 0.07) !important;
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
      box-shadow:
        0 7px 22px rgba(0, 0, 0, 0.045),
        inset 0 1px 0 rgba(255, 255, 255, 0.025) !important;
    }

    /* Keep real blur on fixed chrome only. This preserves the macOS feel
       without forcing the GPU to continuously re-blur long scrolling cards. */
    html body header.navbar,
    html body #sidebar_left,
    html body #pmlt {
      -webkit-backdrop-filter: blur(12px) saturate(130%) !important;
      backdrop-filter: blur(12px) saturate(130%) !important;
    }


    /* =========================================================
       v2.1.9 ROXBOROUGH + MATCHED GLASS CHROME
       Typography and paint only. Roxborough CF is loaded locally when the
       licensed font is installed; elegant serif fallbacks keep the intent.
    ========================================================= */

    @font-face {
      font-family: "US Roxborough";
      src:
        local("Roxborough CF"),
        local("RoxboroughCF"),
        local("Roxborough");
      font-style: normal;
      font-weight: 300 800;
      font-display: swap;
    }

    :root {
      --us-display-font: "US Roxborough", "Iowan Old Style", "Baskerville", "Times New Roman", serif;
      --us-chrome-blue: rgba(7, 22, 37, 0.50);
      --us-chrome-blue-deep: rgba(4, 13, 23, 0.58);
      --us-chrome-line: rgba(150, 207, 255, 0.12);
      --us-chrome-line-bright: rgba(176, 220, 255, 0.17);
    }

    /* Display serif is deliberate and sparse: project identity, not UI data. */
    html body #customer-name h1,
    html body #customer-name h2,
    html body #customer-name h3,
    html body #customer-name .panel-title,
    html body #pmlt h1,
    html body #pmlt h2,
    html body #pmlt .project-number,
    html body #pmlt [class*="project-number" i] {
      font-family: var(--us-display-font) !important;
      font-weight: 500 !important;
      letter-spacing: -0.028em !important;
      font-variant-numeric: lining-nums tabular-nums !important;
      text-rendering: optimizeLegibility !important;
    }

    /* Keep operational UI crisp and modern. */
    html body #customer-info,
    html body #customer-info *,
    html body #us-sign-design-actionbar,
    html body #us-sign-job-overview,
    html body #us-sign-design-summary,
    html body #sidebar_left,
    html body #sidebar_left *,
    html body button,
    html body input,
    html body select,
    html body textarea,
    html body table,
    html body th,
    html body td {
      font-family: var(--us-font) !important;
    }

    /* Top chrome: transparent macOS-style gradient instead of a dark slab. */
    html body header.navbar,
    html body .navbar-fixed-top,
    html body #topbar,
    html body .topbar {
      background:
        linear-gradient(110deg,
          rgba(4, 12, 22, 0.56) 0%,
          rgba(8, 27, 47, 0.43) 32%,
          rgba(14, 48, 72, 0.31) 63%,
          rgba(8, 27, 45, 0.36) 82%,
          rgba(4, 13, 23, 0.50) 100%),
        linear-gradient(180deg,
          rgba(255, 255, 255, 0.055) 0%,
          rgba(255, 255, 255, 0.012) 42%,
          rgba(0, 0, 0, 0.045) 100%) !important;
      background-color: rgba(6, 18, 31, 0.42) !important;
      border-bottom: 1px solid var(--us-chrome-line) !important;
      box-shadow:
        0 8px 24px rgba(0, 0, 0, 0.10),
        inset 0 1px 0 rgba(255, 255, 255, 0.052),
        inset 0 -1px 0 rgba(75, 167, 236, 0.028) !important;
      -webkit-backdrop-filter: blur(14px) saturate(138%) !important;
      backdrop-filter: blur(14px) saturate(138%) !important;
    }

    /* Main left menu: blue-black glass, not neutral gray. */
    html body #sidebar_left {
      background:
        radial-gradient(circle at 4% 10%, rgba(62, 151, 219, 0.14), transparent 34%),
        linear-gradient(180deg,
          rgba(7, 25, 41, 0.69) 0%,
          rgba(5, 18, 31, 0.63) 48%,
          rgba(3, 13, 23, 0.68) 100%) !important;
      background-color: rgba(5, 18, 30, 0.65) !important;
      border-right: 1px solid var(--us-chrome-line) !important;
      box-shadow:
        10px 0 30px rgba(0, 0, 0, 0.09),
        inset -1px 0 0 rgba(255, 255, 255, 0.025),
        inset 0 1px 0 rgba(125, 192, 244, 0.025) !important;
      -webkit-backdrop-filter: blur(12px) saturate(132%) !important;
      backdrop-filter: blur(12px) saturate(132%) !important;
    }

    html body #sidebar_left .nav > li > a,
    html body #sidebar_left a {
      color: rgba(211, 225, 238, 0.82) !important;
    }

    html body #sidebar_left .nav > li > a:hover,
    html body #sidebar_left a:hover {
      color: rgba(248, 251, 255, 0.97) !important;
      background:
        linear-gradient(90deg, rgba(79, 169, 240, 0.11), rgba(79, 169, 240, 0.035)) !important;
    }

    html body #sidebar_left .nav > li.active > a,
    html body #sidebar_left .active > a,
    html body #sidebar_left a.active {
      color: #f5faff !important;
      background:
        linear-gradient(90deg,
          rgba(50, 151, 234, 0.22),
          rgba(27, 102, 177, 0.105) 72%,
          rgba(18, 71, 126, 0.055)) !important;
      border-color: rgba(127, 202, 255, 0.17) !important;
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.032),
        inset 3px 0 0 rgba(108, 191, 255, 0.38) !important;
    }

    /* Project rail uses the same family, but is lighter so the two rails
       separate without looking like unrelated gray/red columns. */
    html body #pmlt {
      background:
        radial-gradient(circle at 0 18%, rgba(70, 155, 220, 0.075), transparent 38%),
        linear-gradient(180deg,
          rgba(7, 22, 37, 0.39) 0%,
          rgba(5, 16, 28, 0.31) 52%,
          rgba(4, 13, 23, 0.37) 100%) !important;
      background-color: rgba(5, 17, 29, 0.34) !important;
      border-right: 1px solid rgba(156, 208, 250, 0.10) !important;
      box-shadow:
        8px 0 26px rgba(0, 0, 0, 0.055),
        inset -1px 0 0 rgba(255, 255, 255, 0.022) !important;
      -webkit-backdrop-filter: blur(10px) saturate(126%) !important;
      backdrop-filter: blur(10px) saturate(126%) !important;
    }

    html body #pmlt a,
    html body #project_menu a {
      color: rgba(211, 227, 241, 0.88) !important;
    }

    html body #pmlt a:hover,
    html body #project_menu a:hover {
      color: #ffffff !important;
      text-shadow: 0 0 14px rgba(103, 190, 255, 0.16) !important;
    }


    /* =========================================================
       v2.1.10 DESCRIPTION TEXT CLEANUP
       Preserve rich-text color and emphasis, but remove pasted/highlighter
       background paint from Description content only.
    ========================================================= */

    html body #descriptionbox .panel-body mark,
    html body #descriptionbox .panel-body .highlight,
    html body #descriptionbox .panel-body [class*="highlight" i],
    html body #descriptionbox .panel-body [style*="background" i],
    html body .us-sign-description-panel .panel-body mark,
    html body .us-sign-description-panel .panel-body .highlight,
    html body .us-sign-description-panel .panel-body [class*="highlight" i],
    html body .us-sign-description-panel .panel-body [style*="background" i] {
      background: transparent !important;
      background-color: transparent !important;
      background-image: none !important;
      box-shadow: none !important;
      text-shadow: none !important;
    }

    /* Keep warning/markup copy readable without the tan/yellow block. */
    html body #descriptionbox .panel-body .text-danger,
    html body #descriptionbox .panel-body font[color="red" i],
    html body #descriptionbox .panel-body [style*="color: red" i],
    html body #descriptionbox .panel-body [style*="color:red" i],
    html body .us-sign-description-panel .panel-body .text-danger,
    html body .us-sign-description-panel .panel-body font[color="red" i],
    html body .us-sign-description-panel .panel-body [style*="color: red" i],
    html body .us-sign-description-panel .panel-body [style*="color:red" i] {
      color: #c98b8b !important;
      background: transparent !important;
      background-color: transparent !important;
      box-shadow: none !important;
      text-shadow: none !important;
    }


    /* v2.1.11 icon restore and light center blur */
    html body .fa,html body i.fa,html body span.fa,html body [class^="fa-"],html body [class*=" fa-"]{font-family:"FontAwesome"!important;font-style:normal!important;font-weight:normal!important;line-height:1!important;}
    html body .glyphicon,html body [class^="glyphicon-"],html body [class*=" glyphicon-"]{font-family:"Glyphicons Halflings"!important;font-style:normal!important;font-weight:normal!important;line-height:1!important;}
    html body .glyphicons,html body [class^="glyphicons-"],html body [class*=" glyphicons-"]{font-family:"Glyphicons"!important;font-style:normal!important;font-weight:normal!important;line-height:1!important;}
    html body .imoon,html body [class^="imoon-"],html body [class*=" imoon-"],html body i[class^="icon-"],html body i[class*=" icon-"],html body span[class^="icon-"],html body span[class*=" icon-"]{font-family:"icomoon"!important;font-style:normal!important;font-weight:normal!important;line-height:1!important;}
    html body #customer-name,html body #customer-info,html body #projectbox,html body #showbtns,html body #descriptionbox,html body #designbox,html body #filesbox,html body #us-sign-design-actionbar,html body #us-sign-job-overview,html body #us-sign-design-summary,html body #us-sign-design-bottom-grid>.us-sign-description-panel,html body #us-sign-design-right-stack>.us-sign-designs-panel,html body #us-sign-design-right-stack>.us-sign-files-panel{-webkit-backdrop-filter:blur(4px) saturate(112%)!important;backdrop-filter:blur(4px) saturate(112%)!important;}
    html body #descriptionbox .panel-body,html body #designbox .panel-body,html body #filesbox .panel-body,html body #projectbox .panel-body,html body #customer-info .panel-body,html body #content table,html body #content .table{-webkit-backdrop-filter:none!important;backdrop-filter:none!important;}


    /* v2.1.12 remove Description rich-text highlight paint */
    html body #descriptionbox :is(mark,.marker,.highlight,[class*="highlight" i],span[style*="background" i],font[style*="background" i],strong[style*="background" i],b[style*="background" i],em[style*="background" i],u[style*="background" i],[bgcolor]),
    html body .us-sign-description-panel :is(mark,.marker,.highlight,[class*="highlight" i],span[style*="background" i],font[style*="background" i],strong[style*="background" i],b[style*="background" i],em[style*="background" i],u[style*="background" i],[bgcolor]),
    html body .us-sign-readable-content :is(mark,.marker,.highlight,[class*="highlight" i],span[style*="background" i],font[style*="background" i],strong[style*="background" i],b[style*="background" i],em[style*="background" i],u[style*="background" i],[bgcolor]){background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;text-shadow:none!important;border:0!important;border-radius:0!important;padding:0!important;}
    html body #descriptionbox :is([style*="color:red" i],[style*="color: red" i],font[color="red" i],font[color="#ff0000" i]),
    html body .us-sign-description-panel :is([style*="color:red" i],[style*="color: red" i],font[color="red" i],font[color="#ff0000" i]),
    html body .us-sign-readable-content :is([style*="color:red" i],[style*="color: red" i],font[color="red" i],font[color="#ff0000" i]){color:#c98b8b!important;-webkit-text-fill-color:#c98b8b!important;background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;text-shadow:none!important;border:0!important;border-radius:0!important;padding:0!important;}


    /* v2.1.13 final Description highlight neutralizer */
    html body :is(#descriptionbox,.us-sign-description-panel,.us-sign-readable-content) :is(mark,.marker,.highlight,[class*="highlight" i],[style*="background" i],[bgcolor]){background:transparent!important;background-color:transparent!important;background-image:none!important;box-shadow:none!important;text-shadow:none!important;border:0!important;border-radius:0!important;padding:0!important;}


    /* =========================================================
       v2.1.14 PROJECT SEARCH GLASS
       Search-page paint only. No geometry, widths, positioning, or polling.
    ========================================================= */
    html.us-sign-search-page #content > .tray320 .admin-form > .panel,
    html.us-sign-search-page #push-down > .pl20.pr50 > .panel,
    html.us-sign-search-page #push-down .panel.heading-border.panel-primary {
      background:
        linear-gradient(145deg, rgba(132, 198, 248, 0.045), transparent 34%),
        linear-gradient(180deg, rgba(8, 18, 30, 0.19), rgba(4, 11, 20, 0.13)) !important;
      background-color: rgba(7, 16, 27, 0.15) !important;
      border: 1px solid rgba(220, 239, 255, 0.10) !important;
      box-shadow:
        0 10px 28px rgba(0, 0, 0, 0.09),
        inset 0 1px 0 rgba(255, 255, 255, 0.045) !important;
      -webkit-backdrop-filter: blur(7px) saturate(126%) !important;
      backdrop-filter: blur(7px) saturate(126%) !important;
    }

    html.us-sign-search-page #content > .tray320 .panel-body.bg-light,
    html.us-sign-search-page #push-down .panel-body.bg-light,
    html.us-sign-search-page #push-down .panel-body {
      background: transparent !important;
      background-color: transparent !important;
      background-image: none !important;
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
    }

    html.us-sign-search-page #push-down .alert.alert-success {
      color: rgba(238, 247, 255, 0.95) !important;
      background:
        linear-gradient(90deg, rgba(78, 165, 235, 0.11), rgba(255, 255, 255, 0.025)) !important;
      background-color: rgba(8, 18, 30, 0.12) !important;
      border: 1px solid rgba(170, 219, 255, 0.12) !important;
      box-shadow:
        0 8px 22px rgba(0, 0, 0, 0.065),
        inset 0 1px 0 rgba(255, 255, 255, 0.04) !important;
      -webkit-backdrop-filter: blur(6px) saturate(124%) !important;
      backdrop-filter: blur(6px) saturate(124%) !important;
    }

    html.us-sign-search-page #form .gui-input,
    html.us-sign-search-page #form select,
    html.us-sign-search-page #form .field.select > select {
      color: rgba(238, 244, 250, 0.92) !important;
      background: rgba(5, 13, 23, 0.34) !important;
      background-color: rgba(5, 13, 23, 0.34) !important;
      border: 1px solid rgba(206, 232, 255, 0.10) !important;
      box-shadow:
        inset 0 1px 2px rgba(0, 0, 0, 0.16),
        inset 0 1px 0 rgba(255, 255, 255, 0.025) !important;
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
    }

    html.us-sign-search-page #form select option {
      color: #e9f0f6 !important;
      background: #101a25 !important;
    }

    html.us-sign-search-page #form .field.select .arrow,
    html.us-sign-search-page #form .field.select .arrow:before,
    html.us-sign-search-page #form .field.select .arrow:after {
      color: rgba(190, 211, 230, 0.72) !important;
      border-color: rgba(190, 211, 230, 0.72) transparent transparent !important;
    }

    html.us-sign-search-page #datatable1,
    html.us-sign-search-page #datatable1 > thead,
    html.us-sign-search-page #datatable1 > tbody,
    html.us-sign-search-page #datatable1 > tbody > tr,
    html.us-sign-search-page #datatable1 > tbody > tr > td {
      background-color: transparent !important;
      background-image: none !important;
    }

    html.us-sign-search-page #datatable1 > thead > tr > th {
      color: rgba(216, 229, 241, 0.90) !important;
      background: rgba(112, 177, 230, 0.055) !important;
      border-color: rgba(220, 239, 255, 0.065) !important;
    }

    html.us-sign-search-page #datatable1 > tbody > tr:hover > td {
      background: rgba(91, 174, 242, 0.06) !important;
    }

    html.us-sign-search-page .pagination > li > a,
    html.us-sign-search-page .pagination > li > span {
      background: rgba(7, 16, 27, 0.24) !important;
      border-color: rgba(220, 239, 255, 0.09) !important;
      color: rgba(215, 228, 240, 0.88) !important;
    }

    html.us-sign-search-page .pagination > .active > a,
    html.us-sign-search-page .pagination > .active > span {
      background: rgba(72, 160, 231, 0.26) !important;
      border-color: rgba(125, 199, 255, 0.18) !important;
      color: #f6fbff !important;
    }


    /* =========================================================
       v2.1.15 TASK PAGE TEXT CONTRAST
       Task-page only. Fix native black task copy without changing
       layout, geometry, or the red completion/status messaging.
    ========================================================= */
    html.us-sign-task-page #content .panel-body,
    html.us-sign-task-page #content .panel-body td,
    html.us-sign-task-page #content .panel-body th,
    html.us-sign-task-page #content .panel-body p,
    html.us-sign-task-page #content .panel-body div,
    html.us-sign-task-page #content .panel-body span,
    html.us-sign-task-page #content .panel-body li,
    html.us-sign-task-page #content .panel-body label,
    html.us-sign-task-page #content .panel-body small,
    html.us-sign-task-page #content .panel-body strong,
    html.us-sign-task-page #content .panel-body b {
      color: rgba(232, 239, 247, 0.90) !important;
      -webkit-text-fill-color: currentColor !important;
      text-shadow: none !important;
    }

    html.us-sign-task-page #content .panel-body a:not(.btn) {
      color: rgba(174, 216, 250, 0.94) !important;
      -webkit-text-fill-color: currentColor !important;
    }

    html.us-sign-task-page #content .panel-body :is(
      [style*="color: black" i],
      [style*="color:black" i],
      [style*="color: #000" i],
      [style*="color:#000" i],
      [style*="color: rgb(0" i],
      font[color="black" i],
      font[color="#000" i],
      font[color="#000000" i]
    ) {
      color: rgba(232, 239, 247, 0.90) !important;
      -webkit-text-fill-color: rgba(232, 239, 247, 0.90) !important;
    }

    /* Preserve completion/error emphasis after the broad task text repair. */
    html.us-sign-task-page #content .panel-body :is(
      .text-danger,
      .danger,
      [style*="color: red" i],
      [style*="color:red" i],
      [style*="color: #ff0000" i],
      [style*="color:#ff0000" i],
      font[color="red" i],
      font[color="#ff0000" i]
    ) {
      color: #ff6257 !important;
      -webkit-text-fill-color: #ff6257 !important;
    }


    /* v2.1.16 JOB DASHBOARD GLASS BLUR */
    html.us-sign-job-dashboard #customer-name,
    html.us-sign-job-dashboard #customer-info,
    html.us-sign-job-dashboard #content .tray-center > .pl15.pr15 > .well:has(.important-notes) {
      background: linear-gradient(145deg, rgba(115,188,244,.040), transparent 34%), linear-gradient(180deg, rgba(7,16,28,.17), rgba(4,10,18,.11)) !important;
      background-color: rgba(7,15,26,.13) !important;
      border-color: rgba(216,238,255,.105) !important;
      box-shadow: 0 12px 30px rgba(0,0,0,.085), inset 0 1px 0 rgba(255,255,255,.042) !important;
      -webkit-backdrop-filter: blur(8px) saturate(120%) !important;
      backdrop-filter: blur(8px) saturate(120%) !important;
    }

    html.us-sign-job-dashboard #customer-info :is(.panel-heading,.panel-body,button,a.btn),
    html.us-sign-job-dashboard #content .tray-center > .pl15.pr15 > .well:has(.important-notes) :is(.panel,.panel-heading,.panel-body,input,textarea,button,a.btn) {
      -webkit-backdrop-filter: none !important;
      backdrop-filter: none !important;
    }


    /* =========================================================
       v2.1.17 CUSTOM CURSOR
       CSS-only cursor assets. No mouse tracking or animation loop.
    ========================================================= */
    @media (pointer: fine) {
      html,
      body {
        cursor: url("https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/assets/us-sign-cursor-arrow-elegant-v218.svg") 4 3, default !important;
      }

      a,
      button,
      .btn,
      [role="button"],
      summary,
      select,
      label[for],
      input[type="button"],
      input[type="submit"],
      input[type="reset"],
      input[type="checkbox"],
      input[type="radio"] {
        cursor: url("https://raw.githubusercontent.com/Wakeup-gif/test_repo/main/tampermonkey/assets/us-sign-cursor-pointer-elegant-v218b.svg") 4 3, pointer !important;
      }

      input:not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="checkbox"]):not([type="radio"]),
      textarea,
      [contenteditable="true"],
      .cke_editable,
      .cke_contents,
      .cke_contents iframe {
        cursor: text !important;
      }

      [disabled],
      .disabled,
      [aria-disabled="true"] {
        cursor: not-allowed !important;
      }

      [class*="resize" i],
      [class*="resizer" i],
      .ui-resizable-handle {
        cursor: revert !important;
      }
    }

    @media print {
      html,
      body,
      #main,
      #content_wrapper,
      #content,
      .tray,
      .tray-left,
      .tray-right,
      .tray-center,
      .panel,
      .well,
      table,
      .table {
        color: #000 !important;
        background: #fff !important;
        box-shadow: none !important;
      }
    }
  `);

  // v2.1.13: bounded cleanup for inline rich-text highlight paint that can
  // outrank stylesheet rules. No observer and no recurring interval.
  function usSignClearDescriptionHighlightPaint() {
    const roots = document.querySelectorAll('#descriptionbox, .us-sign-description-panel, .us-sign-readable-content');
    roots.forEach((root) => {
      root.querySelectorAll('mark, .marker, .highlight, [class*="highlight" i], [style*="background" i], [bgcolor]').forEach((el) => {
        if (el.hasAttribute('bgcolor')) el.removeAttribute('bgcolor');
        el.style.setProperty('background', 'transparent', 'important');
        el.style.setProperty('background-color', 'transparent', 'important');
        el.style.setProperty('background-image', 'none', 'important');
        el.style.setProperty('box-shadow', 'none', 'important');
        el.style.setProperty('text-shadow', 'none', 'important');
        el.style.setProperty('border', '0', 'important');
        el.style.setProperty('border-radius', '0', 'important');
        el.style.setProperty('padding', '0', 'important');
      });
    });
  }

  function usSignScheduleDescriptionCleanup() {
    [0, 180, 500, 1100, 2200, 3600].forEach((delay) => {
      window.setTimeout(usSignClearDescriptionHighlightPaint, delay);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', usSignScheduleDescriptionCleanup, { once: true });
  } else {
    usSignScheduleDescriptionCleanup();
  }
  window.addEventListener('pageshow', usSignScheduleDescriptionCleanup);


  // v2.1.14: URL-scoped Project Search marker. No observer or polling.
  if (/\/search\.php$/i.test(window.location.pathname)) {
    document.documentElement.classList.add("us-sign-search-page");
  }


  // v2.1.15: mark the project Task page from its own native UI.
  // One DOM-ready check plus pageshow; no observer and no polling.
  function usSignMarkTaskPage() {
    const taskSearch = document.querySelector('input[placeholder*="Search Tasks" i]');
    if (!taskSearch) return;

    const headings = document.querySelectorAll('.panel-heading, .panel-title, h1, h2, h3, h4');
    const hasSelectedTask = Array.from(headings).some((el) => /Selected\s+Task/i.test(el.textContent || ''));
    const hasTasksPanel = Array.from(headings).some((el) => /^\s*Tasks\s*$/i.test(el.textContent || ''));

    if (hasSelectedTask || hasTasksPanel) {
      document.documentElement.classList.add('us-sign-task-page');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', usSignMarkTaskPage, { once: true });
  } else {
    usSignMarkTaskPage();
  }
  window.addEventListener('pageshow', usSignMarkTaskPage);


  function usSignMarkJobDashboard() {
    const hasCustomer = !!document.querySelector('#customer-info');
    const hasImportantNotes = !!document.querySelector('.important-notes');
    const isScope = !!document.querySelector('#ps-select, .us-sign-scope-enhanced');
    const isDesign = !!document.querySelector('#us-sign-design-actionbar, #us-sign-design-bottom-grid');
    if (hasCustomer && hasImportantNotes && !isScope && !isDesign) document.documentElement.classList.add('us-sign-job-dashboard');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', usSignMarkJobDashboard, { once: true });
  else usSignMarkJobDashboard();
  window.addEventListener('pageshow', usSignMarkJobDashboard);

})();

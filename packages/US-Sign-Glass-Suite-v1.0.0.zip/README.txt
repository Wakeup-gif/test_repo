US Sign Glass Suite 1.0.0

Install the theme and companion userscripts in this ZIP.
Only enable one US Sign visual theme at a time.

Included:
- US-Sign-Glass-Theme.user.js
- US-Sign-Design-Job-Tools.user.js
- US-Sign-Project-Scope-Workspace.user.js
- US-Sign-Menu-Cleanup.user.js
- US-Sign-Description-File-Path-Tools.user.js
- US-Sign-Scope-of-Work-File-Tools.user.js
- US-Sign-UI-Runtime-Fixes.user.js

Frozen pre-Dark-Glass companion set. This package preserves the established Glass UI exactly.
